<?php

define('APP_ROOT', realpath(dirname(__FILE__)));
define('CONTROLLER_ACCESSOR', 'controller');
define('ACTION_ACCESSOR', 'page');

require "bootstrap/autoload.php";
require "bootstrap/setup.php";

use App\Framework\Application;

$app = new Application();

echo $app->generateRequest()->getResponse();