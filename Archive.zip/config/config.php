<?php

return [
	'default_controller' =>	'Home',
	'default_action' =>		'index',
];