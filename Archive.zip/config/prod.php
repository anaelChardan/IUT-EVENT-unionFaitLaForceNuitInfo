<?php

return [
	'database' => [
			'driver' =>		'sqlsrv',
			'host' =>		'info-simplet',
			'username' =>	'ETD',
			'password' =>	'ETD',
			'dbname' =>		'Classique',
		]
];