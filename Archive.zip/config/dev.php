<?php

return [
	'database' => [
			'driver' =>		'mysql',
			'host' =>		'localhost',
			'username' =>	'root',
			'password' =>	'root',
			'dbname' =>		'testProjet',
		]
];