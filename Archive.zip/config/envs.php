<?php

return [
	'dev' => ['server.local'],
	'prod' => ['INFO-TIMIDE']
];