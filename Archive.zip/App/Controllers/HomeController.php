<?php

namespace App\Controllers;

use App\Framework\Controller;

class HomeController extends Controller {
	public function getIndex() {
		$res = $this->app->db->execute('SELECT * FROM Genre');
		return $this->naturalView(["test"=>"test", "dump"=>var_dump($res)]);
	}

	public function getForm() {
		return $this->naturalView(["adding"=>true]);
	}

	public function postForm() {
		return "Bonjour ".$this->request->name;
	}
}

?>