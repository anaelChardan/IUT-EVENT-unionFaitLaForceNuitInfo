<?php

namespace App\Models;

use App\Framework\Model;

class User extends Model {

	public function __construct() {
		parent::__construct();
	}

}