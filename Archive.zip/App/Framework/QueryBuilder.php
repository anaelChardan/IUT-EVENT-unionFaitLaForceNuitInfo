<?php

namespace App\Framework;

class QueryBuilder {
	protected $tableName;

	function __construct($tableName) {
		$this->tableName = $tableName;
	}


}