<?php

namespace App\Framework;

class Model {
	private $db;
	protected $table = NULL;

	public function __construct() {
		global $app;
		$this->db = $app->db;
		if ($this->table === NULL) {
			$refl = new \ReflectionClass(get_class($this));
			$this->table = strtolower($refl->getShortName()).'s';
		}
	}

	public function hydrate() {
		
	}

	public function getTableName() {
		return $this->table;
	}
}