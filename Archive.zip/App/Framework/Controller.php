<?php 

namespace App\Framework;

class Controller {
	public $request;
	protected $app;

	function __construct($request) {
		$this->request = $request;
		$this->app = $this->request->app;
	}

	public function view($name, $vars = []) {
		global $twig;
		echo $twig->render($name, $vars);
	}

	public function naturalView($vars = []) {
		$ctlName = $this->request->getApplication()->getControllerName();
		$actionName = $this->request->getApplication()->getRawActionName();
		return $this->view($ctlName.'/'.$actionName.'.html.twig');
	}

	public function repo($name) {
		$repo = new Repository($name);
		return $repo;
	}
}