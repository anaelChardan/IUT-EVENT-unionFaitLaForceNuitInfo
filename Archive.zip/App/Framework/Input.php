<?php

namespace App\Framework;

class Input {

	public static function has($name) {
		return array_key_exists($name, $_REQUEST);
	}

	public static function get($name, $fallback = '') {
		return static::has($name) ? $_REQUEST[$name] : $fallback;
	}
}