<?php

namespace App\Framework;

class Repository {
	private $modelName;

	public function __construct($modelName) {
		$this->modelName = $modelName;
	}

	public function query() {
		$name = 'App\\Models\\'.$this->modelName;
		$model = new $name();
		$qb = new QueryBuilder($model->getTableName());
		return $qb;
	}
}