<?php

namespace App\Framework;

class Database {

	private $pdo;

	public function __construct($app) {
		if ($app->getConfig('database', 'driver') == 'sqlsrv')
			$connectionStr = 'sqlsrv:Server='.$app->getConfig('database', 'host').';Database='.$app->getConfig('database', 'dbname');
		else
			$connectionStr = $app->getConfig('database', 'driver').':host='.$app->getConfig('database', 'host').';dbname='.$app->getConfig('database', 'dbname');
		$this->pdo = new \PDO($connectionStr, $app->getConfig('database', 'username'), $app->getConfig('database', 'password'));
	}

	public function execute($query, $params = []) {
		$res = [];
		$query = $this->pdo->prepare($query);

		foreach ($params as $name => $value) {
			$query->bindParam($name, $value);
		}

		if ($query->execute()) {
			$res = $query->fetchAll();
			foreach ($res as $i=>$row) {
				foreach ($row as $key=>$val) {
					if (is_numeric($key))
						unset($res[$i][$key]);
				}
			}
		}
		return $res;
	}

	public function first($query, $params = []) {
		$res = $this->execute($query, $params);
		return count($res) > 0 ? $res[0] : NULL;
	}

	public function close() {
		$this->pdo = null;
	}

	public function __destruct() {
		$this->close();
	}

}